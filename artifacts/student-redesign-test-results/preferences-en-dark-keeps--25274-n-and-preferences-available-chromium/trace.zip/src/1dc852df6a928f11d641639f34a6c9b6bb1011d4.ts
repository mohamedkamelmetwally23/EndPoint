import { expect, test, type Page } from '@playwright/test';

type Language = 'ar' | 'en';
type Theme = 'dark' | 'light';

async function mockAuthenticatedStudent(page: Page, language: Language, theme: Theme): Promise<void> {
  await page.addInitScript(({ language: savedLanguage, theme: savedTheme }) => {
    localStorage.setItem('endpoint.language', savedLanguage);
    localStorage.setItem('endpoint.theme', savedTheme);
  }, { language, theme });

  await page.route('http://localhost:4000/api/v1/**', async (route) => {
    const path = new URL(route.request().url()).pathname;
    if (path.endsWith('/auth/device')) return route.fulfill({ json: { success: true, data: { initialized: true } } });
    if (path.endsWith('/auth/refresh')) return route.fulfill({ json: { success: true, data: { accessToken: 'browser-test-token' } } });
    if (path.endsWith('/auth/me')) return route.fulfill({ json: { success: true, data: {
      id: 'student-1', name: 'Ahmed Mohamed', email: 'ahmed@example.com', roles: ['student'], permissions: [], preferences: { language, theme },
    } } });
    if (path.endsWith('/users/me/preferences')) return route.fulfill({ json: { success: true, data: { language, theme } } });
    if (path.endsWith('/students/me/timeline')) return route.fulfill({ json: { success: true, data: [] } });
    return route.fulfill({ status: 404, json: { success: false } });
  });
}

for (const language of ['en', 'ar'] as const) {
  for (const theme of ['light', 'dark'] as const) {
    test(`${language} + ${theme} keeps student navigation and preferences available`, async ({ page }) => {
      await mockAuthenticatedStudent(page, language, theme);
      await page.goto('/student');
      await expect(page).toHaveURL(/\/student\/timeline$/);
      await expect(page.locator('main h1')).toBeVisible();
      await expect(page.locator('html')).toHaveAttribute('lang', language);
      await expect(page.locator('html')).toHaveAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
      await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
      await expect(page.locator('.sidebar-menu a')).toHaveText(language === 'ar' ? ['الجدول الزمني', 'حسابي', 'استكشف'] : ['Timeline', 'Profile', 'Explore']);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
      await page.locator('.preferences .preference-toggle').first().click();
      await expect(page.locator('html')).toHaveAttribute('dir', language === 'ar' ? 'ltr' : 'rtl');
      await page.locator('.preferences .preference-toggle').nth(1).click();
      await expect(page.locator('html')).toHaveAttribute('data-theme', theme === 'light' ? 'dark' : 'light');
    });
  }
}

test('Arabic dark mode remains responsive on a mobile viewport', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await mockAuthenticatedStudent(page, 'ar', 'dark');
  await page.goto('/student');
  await expect(page.locator('main h1')).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await expect(page.locator('.mobile-nav a')).toHaveCount(3);
  await expect(page.getByRole('button', { name: /Sign out|تسجيل الخروج/ })).toBeVisible();
});
