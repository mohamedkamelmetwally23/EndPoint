import { expect, test, type Page, type Route } from '@playwright/test';

/** Returns the fulfilment promise when it handles the route, or undefined to fall through to 404. */
type Handler = (route: Route, path: string) => Promise<void> | undefined;

const ok = (route: Route, data: unknown, status = 200) => route.fulfill({ status, json: { success: true, data } });
const subject = { id: 'sub1', code: 'CS 203', name: { en: 'Data Structures', ar: 'هياكل البيانات' } };
const student = { id: 's1', name: 'Mariam Ali', email: 'mariam@example.com', avatarUrl: null };
const row = { student, subjects: [subject], progressPercent: 50, lastActivityAt: '2026-09-26T10:00:00Z', quiz: { attempted: 1, total: 2, passed: 1, averagePercent: 90 }, assignments: { submitted: 1, total: 1 } };
const activity = { kind: 'quiz_submitted', at: '2026-09-26T10:00:00Z', student: { id: 's1', name: 'Mariam Ali' }, subject, title: { en: 'Linked lists' }, percent: 90, passed: true };

async function mockLecturer(page: Page, extra: Handler = () => undefined, language: 'en' | 'ar' = 'en', permissions = ['student:read', 'analytics:read', 'expense:manage']): Promise<void> {
  await page.addInitScript((lang) => {
    localStorage.setItem('endpoint.language', lang);
    localStorage.setItem('endpoint.theme', 'light');
  }, language);
  await page.route('http://localhost:4000/api/v1/**', async (route) => {
    const path = new URL(route.request().url()).pathname.replace('/api/v1', '');
    if (path === '/auth/device') return ok(route, { initialized: true });
    if (path === '/auth/refresh') return ok(route, { accessToken: 'token' });
    if (path === '/auth/me') return ok(route, { id: 'l1', name: 'Dr. Salma Nabil', email: 'salma@endpoint.dev', roles: ['lecturer'], permissions, preferences: { language, theme: 'light' } });
    return extra(route, path) ?? route.fulfill({ status: 404, json: { success: false } });
  });
}

test('lecturer navigation and home use real lecturer data', async ({ page }) => {
  await mockLecturer(page, (route, path) => (path === '/lecturer/overview' ? ok(route, { subjects: 2, students: 14, averageProgress: 63, activeStudents: 9, recentActivity: [activity] }) : undefined));
  await page.goto('/lecturer');
  await expect(page.locator('.sidebar-link span')).toHaveText(['Home', 'My Subjects', 'Students', 'Analytics', 'Accounts']);
  await expect(page.locator('.stat-card strong')).toHaveText(['2', '14', '63%', '9']);
  await expect(page.locator('.activity-feed li')).toContainText('Mariam Ali submitted the quiz in · Linked lists · 90%');
});

test('subjects are view-only and open a detail page with students', async ({ page }) => {
  await mockLecturer(page, (route, path) => {
    if (path === '/lecturer/subjects') return ok(route, [{ ...subject, description: null, packageCount: 1, lessonCount: 8, studentCount: 14, averageProgress: 63 }]);
    if (path === '/lecturer/subjects/sub1') return ok(route, {
      subject: { ...subject, description: null, packageCount: 1, lessonCount: 8, studentCount: 1, averageProgress: 50 },
      packages: [{ id: 'p1', title: { en: 'Midterm' }, status: 'published', released: true, lessonCount: 8, studentCount: 1, averageProgress: 50 }],
      students: [row],
    });
    return undefined;
  });
  await page.goto('/lecturer/subjects');
  await expect(page.locator('main').getByRole('button')).toHaveCount(0);
  await page.locator('.manage-card', { hasText: 'Data Structures' }).click();
  await expect(page).toHaveURL(/\/lecturer\/subjects\/sub1$/);
  await expect(page.locator('main h1')).toHaveText('Data Structures');
  await expect(page.locator('.student-cell')).toHaveText(/Mariam Ali/);
});

test('students list links to a read-only profile with quizzes and submitted files', async ({ page }) => {
  await mockLecturer(page, (route, path) => {
    if (path === '/lecturer/students') return ok(route, [row, { ...row, student: { ...student, id: 's2', name: 'Omar Adel', email: 'omar@example.com' }, progressPercent: 0, lastActivityAt: null }]);
    if (path === '/lecturer/students/s1') return ok(route, {
      student, overallProgress: 50, lastActivityAt: '2026-09-26T10:00:00Z', quiz: row.quiz, assignments: row.assignments,
      packages: [{ packageId: 'p1', title: { en: 'Midterm' }, subject, progress: { completed: 4, total: 8, percent: 50 }, lastActivityAt: '2026-09-26T10:00:00Z' }],
      materials: [{ materialId: 'm1', title: { en: 'Linked lists' }, subject, status: 'completed', lastAccessedAt: '2026-09-26T10:00:00Z', completedAt: '2026-09-26T10:00:00Z' }],
      quizAttempts: [{ attemptId: 'a1', quizId: 'q1', materialTitle: { en: 'Linked lists' }, subject, score: 9, maxScore: 10, percent: 90, passed: true, submittedAt: '2026-09-26T10:00:00Z' }],
      submissions: [{ id: 'x1', materialId: 'm1', materialTitle: { en: 'Linked lists' }, assignmentTitle: { en: 'Homework 1' }, subject, note: 'Done early', files: [{ id: 'f1', fileName: 'homework.pdf', contentType: 'application/pdf', size: 2048 }], submittedAt: '2026-09-25T10:00:00Z', dueAt: '2026-09-28T10:00:00Z', late: false }],
      recentActivity: [activity],
    });
    return undefined;
  });
  await page.goto('/lecturer/students');
  await expect(page.locator('.manage-table tbody tr')).toHaveCount(2);
  await page.getByPlaceholder('Search by name or email').fill('omar');
  await expect(page.locator('.manage-table tbody tr')).toHaveCount(1);
  await page.getByPlaceholder('Search by name or email').fill('');
  await page.getByRole('link', { name: /Mariam Ali/ }).click();
  await expect(page).toHaveURL(/\/lecturer\/students\/s1$/);
  await expect(page.locator('main h1')).toHaveText('Mariam Ali');
  await expect(page.locator('.submission-entry')).toContainText('Homework 1');
  await expect(page.locator('.submission-entry .file-link')).toContainText('homework.pdf');
  await expect(page.locator('main table tbody tr')).toContainText(['Linked lists']);
  await expect(page.locator('main').getByRole('button', { name: /grant|revoke|edit|delete/i })).toHaveCount(0);
});

test('analytics renders lecturer-scoped figures', async ({ page }) => {
  const days = Array.from({ length: 14 }, (_, index) => ({ date: `2026-09-${String(14 + index).padStart(2, '0')}`, count: index % 3 }));
  await mockLecturer(page, (route, path) => (path === '/lecturer/analytics' ? ok(route, {
    summary: { subjects: 1, students: 14, activeStudents: 9, averageProgress: 63, quizAttempts: 20, averageQuizScore: 71, passRate: 80, assignmentCompletion: 55 },
    progressDistribution: [{ bucket: '0-24', count: 2 }, { bucket: '25-49', count: 3 }, { bucket: '50-74', count: 5 }, { bucket: '75-100', count: 4 }],
    activityByDay: days,
    subjects: [{ subject, students: 14, activeStudents: 9, averageProgress: 63, quizAttempts: 20, averageQuizScore: 71, passRate: 80, assignmentCompletion: 55 }],
  }) : undefined));
  await page.goto('/lecturer/analytics');
  await expect(page.locator('.stat-card strong')).toHaveText(['63%', '9 / 14', '71%', '55%']);
  await expect(page.locator('.chart-bars > div')).toHaveCount(14);
  await expect(page.locator('.distribution-list li')).toHaveCount(4);
});

test('lecturer Accounts uses the shared expense system', async ({ page }) => {
  await mockLecturer(page, (route, path) => (path === '/manage/expenses'
    ? ok(route, { items: [{ id: 'e1', title: 'Camera', category: 'equipment', amount: 900, currency: 'EGP', date: '2026-09-01T00:00:00Z', description: null, notes: null, receipt: null, createdBy: { id: 'l1', name: 'Dr. Salma Nabil' }, canEdit: true, createdAt: '2026-09-01T00:00:00Z', updatedAt: '2026-09-01T00:00:00Z' }], total: 1, page: 1, pageSize: 25, totals: [{ currency: 'EGP', amount: 900 }] })
    : undefined));
  await page.goto('/lecturer/accounts');
  await expect(page.locator('.manage-table tbody tr')).toHaveCount(1);
  await expect(page.getByRole('button', { name: 'Edit expense: Camera' })).toBeVisible();
});

test('without expense or analytics permission those areas are hidden and blocked', async ({ page }) => {
  await mockLecturer(page, () => undefined, 'en', ['student:read']);
  await page.goto('/lecturer/students');
  await expect(page.locator('.sidebar-link span')).toHaveText(['Home', 'My Subjects', 'Students']);
  await page.goto('/lecturer/accounts');
  await expect(page).toHaveURL(/\/forbidden$/);
});

test('students page works in Arabic without horizontal overflow', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await mockLecturer(page, (route, path) => (path === '/lecturer/students' ? ok(route, [row]) : undefined), 'ar');
  await page.goto('/lecturer/students');
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  await expect(page.locator('.manage-table tbody tr')).toHaveCount(1);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});
