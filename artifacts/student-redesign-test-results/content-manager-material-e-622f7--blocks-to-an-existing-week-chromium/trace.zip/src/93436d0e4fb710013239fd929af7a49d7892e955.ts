import { expect, test, type Page, type Route } from '@playwright/test';

/** Returns the fulfilment promise when it handles the route, or undefined to fall through to 404. */
type Handler = (route: Route, path: string) => Promise<void> | undefined;

const pkg = { id: 'p1', grade: 1, term: 1, title: { en: 'Midterm Package' }, status: 'published', weekCount: 1, materialCount: 0, price: 500, currency: 'EGP', activeAccessCount: 0, subject: null };
const outline = { package: { id: 'p1', grade: 1, term: 1, title: { en: 'Midterm Package' }, status: 'published', weeks: [{ id: 'w1', order: 1, title: { en: 'Linked lists' }, materials: [] }] } };
const subjects = [{ id: 's1', name: { en: 'Programming' }, code: null, weekCount: 1, materialCount: 0 }];

async function mockStaff(page: Page, permissions: string[], extra: Handler = () => undefined, language: 'en' | 'ar' = 'en', theme: 'light' | 'dark' = 'light'): Promise<void> {
  await page.addInitScript(({ lang, prefTheme }) => {
    localStorage.setItem('endpoint.language', lang);
    localStorage.setItem('endpoint.theme', prefTheme);
  }, { lang: language, prefTheme: theme });
  await page.route('http://localhost:4000/api/v1/**', async (route) => {
    const path = new URL(route.request().url()).pathname.replace('/api/v1', '');
    if (path === '/auth/device') return route.fulfill({ json: { success: true, data: { initialized: true } } });
    if (path === '/auth/refresh') return route.fulfill({ json: { success: true, data: { accessToken: 'token' } } });
    if (path === '/auth/me') return route.fulfill({ json: { success: true, data: { id: 'u1', name: 'Nour Hassan', email: 'nour@endpoint.dev', roles: ['content_manager'], permissions, preferences: { language, theme } } } });
    const handled = extra(route, path);
    return handled ?? route.fulfill({ status: 404, json: { success: false } });
  });
}

const ok = (route: Route, data: unknown, status = 200) => route.fulfill({ status, json: { success: true, data } });
const all = ['content:create', 'content:update', 'content:publish', 'subject:create', 'subject:update', 'package:create', 'package:update', 'expense:manage'];

test('content manager navigation is Home, Content, Packages, Accounts', async ({ page }) => {
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/overview') return ok(route, { courses: 1, packages: 2, materials: 3, materialsByStatus: { draft: 1, published: 1, scheduled: 1 }, recentActivity: [] });
    if (path === '/manage/packages') return ok(route, [pkg]);
    return undefined;
  });
  await page.goto('/content');
  await expect(page.locator('.sidebar-link span')).toHaveText(['Home', 'Content', 'Packages', 'Accounts']);
  await expect(page.locator('.cm-dashboard-stat strong')).toHaveText(['2', '1', '1', '1']);
  await page.locator('.sidebar-link[href="/content/courses"]').click();
  await page.getByRole('link', { name: /First year/ }).click();
  await page.getByRole('link', { name: /Term 1/ }).click();
  await expect(page.locator('.cm-package-card')).toHaveCount(1);
  await expect(page.locator('.cm-package-card')).toContainText('Midterm Package');
});

test('package shows subjects; weeks can be added only inside a subject', async ({ page }) => {
  let weeks = [...outline.package.weeks];
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1') return ok(route, pkg);
    if (path === '/manage/packages/p1/subjects') return ok(route, subjects);
    if (path === '/manage/courses') return ok(route, []);
    if (path === '/manage/packages/p1/subjects/s1/outline') return ok(route, { package: { ...outline.package, weeks } });
    if (path === '/manage/packages/p1/subjects/s1/weeks' && route.request().method() === 'POST') {
      const body = route.request().postDataJSON() as { order: number; title: { en: string } };
      weeks = [...weeks, { id: 'w2', order: body.order, title: body.title, materials: [] }];
      return ok(route, { id: 'w2', packageId: 'p1', order: body.order, title: body.title, materialCount: 0 }, 201);
    }
    return undefined;
  });
  await page.goto('/content/courses/p1');
  await expect(page.getByRole('link', { name: /Programming/ })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Add week' })).toHaveCount(0);
  await expect(page.getByText('Linked lists')).toHaveCount(0);
  await page.getByRole('link', { name: /Programming/ }).click();
  await expect(page.getByRole('button', { name: /Linked lists/ })).toBeVisible();
  await expect(page.getByRole('link', { name: 'Add New Content' })).toHaveAttribute('href', '/content/courses/p1/subjects/s1/weeks/w1/materials/new');
  await page.getByRole('button', { name: 'Add week' }).click();
  await page.getByLabel('Week title (optional) (English)').fill('Trees');
  await page.getByRole('button', { name: 'Save', exact: true }).click();
  await expect(page.getByRole('button', { name: /Trees/ })).toBeVisible();
});

test('existing subject details can be copied into a package', async ({ page }) => {
  let assigned = [...subjects];
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1') return ok(route, pkg);
    if (path === '/manage/packages/p1/subjects' && route.request().method() === 'POST') {
      expect(route.request().postDataJSON()).toEqual({ subjectId: 's2' });
      assigned = [...assigned, { id: 's2-copy', name: { en: 'Mathematics' }, code: null, weekCount: 0, materialCount: 0 }];
      return ok(route, assigned, 201);
    }
    if (path === '/manage/packages/p1/subjects') return ok(route, assigned);
    if (path === '/manage/courses') return ok(route, [{ id: 's1', name: { en: 'Programming' } }, { id: 's2', name: { en: 'Mathematics' } }]);
    return undefined;
  });
  await page.goto('/content/courses/p1');
  await page.getByRole('button', { name: 'Add Subject' }).click();
  await page.getByRole('combobox', { name: 'Copy an existing subject name' }).selectOption('s2');
  await page.getByRole('button', { name: 'Copy subject details' }).click();
  await expect(page.getByRole('link', { name: /Mathematics/ })).toBeVisible();
});

test('a new subject is created directly inside its selected package', async ({ page }) => {
  let assigned = [...subjects];
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1') return ok(route, pkg);
    if (path === '/manage/packages/p1/subjects') {
      expect(route.request().method()).toBe('GET');
      return ok(route, assigned);
    }
    if (path === '/manage/courses' && route.request().method() === 'POST') {
      expect(route.request().postDataJSON()).toMatchObject({ packageId: 'p1', name: { en: 'Physics' }, status: 'draft' });
      const created = { id: 'new-subject', name: { en: 'Physics' }, code: null, weekCount: 0, materialCount: 0 };
      assigned = [...assigned, created];
      return ok(route, created, 201);
    }
    if (path === '/manage/courses') return ok(route, []);
    return undefined;
  });
  await page.goto('/content/courses/p1');
  await page.getByRole('button', { name: 'Add Subject' }).click();
  await page.getByLabel('New subject name (English)').fill('Physics');
  await page.getByRole('button', { name: 'Create subject', exact: true }).click();
  await expect(page.getByRole('link', { name: /Physics/ })).toBeVisible();
});

test('opening a week shows its lectures and the add material action', async ({ page }) => {
  const material = { id: 'm1', title: { en: 'Lecture 1' }, status: 'draft', scheduledAt: null, kinds: ['video'], blockCount: 2, updatedAt: '2026-09-01T00:00:00Z' };
  await mockStaff(page, all, (route, path) => path === '/manage/packages/p1/subjects/s1/outline'
    ? ok(route, { package: { ...outline.package, weeks: [{ ...outline.package.weeks[0], materials: [material] }] } })
    : undefined);
  await page.goto('/content/courses/p1/subjects/s1/weeks/w1');
  await expect(page.locator('.week-material')).toContainText('Lecture 1');
  await expect(page.locator('.week-material')).toContainText('Draft');
  await expect(page.locator('.week-material')).toContainText('2 content blocks');
  await expect(page.locator('.week-material')).toContainText('Video');
  await expect(page.getByRole('link', { name: 'Open' })).toHaveAttribute('href', '/content/materials/m1/view');
  await expect(page.getByRole('link', { name: 'Edit' })).toHaveAttribute('href', '/content/materials/m1');
  await expect(page.getByRole('link', { name: 'Add New Content' })).toHaveAttribute('href', '/content/courses/p1/subjects/s1/weeks/w1/materials/new');
});

test('Open previews blocks while Edit starts with block forms collapsed', async ({ page }) => {
  const material = { id: 'm1', title: { en: 'Lecture 1' }, status: 'draft', scheduledAt: null, publishedAt: null, updatedAt: '2026-09-01T00:00:00Z', weekId: 'w1', packageId: 'p1', subjectId: 's1', blocks: [{ id: 'b1', kind: 'text', title: null, body: { en: 'Read chapter 3.' } }] };
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/materials/m1') return ok(route, material);
    if (path === '/manage/packages/p1/subjects/s1/outline') return ok(route, outline);
    return undefined;
  });
  await page.goto('/content/materials/m1/view');
  await expect(page.getByText('Read chapter 3.')).toBeVisible();
  await page.getByRole('link', { name: 'Edit' }).click();
  await expect(page.locator('.block-card')).toHaveCount(1);
  await expect(page.locator('.block-card__toggle')).toHaveAttribute('aria-expanded', 'false');
  await expect(page.getByLabel('Text (English)')).toHaveCount(0);
  await page.locator('.block-card__toggle').click();
  await expect(page.getByLabel('Text (English)')).toBeVisible();
});

test('Add New Content from an existing material uses a page and preserves its blocks', async ({ page }) => {
  const material = { id: 'm1', title: { en: 'Lecture 1' }, status: 'draft', scheduledAt: null, publishedAt: null, updatedAt: '2026-09-01T00:00:00Z', weekId: 'w1', packageId: 'p1', subjectId: 's1', blocks: [{ id: 'b1', kind: 'text', title: null, body: { en: 'Read chapter 3.' } }] };
  let saved: { blocks?: { kind: string }[] } | null = null;
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/materials/m1' && route.request().method() === 'PUT') { saved = route.request().postDataJSON() as typeof saved; return ok(route, material); }
    if (path === '/manage/materials/m1') return ok(route, material);
    if (path === '/manage/packages/p1/subjects/s1/outline') return ok(route, outline);
    return undefined;
  });
  await page.goto('/content/materials/m1/view');
  await page.getByRole('link', { name: 'Add New Content' }).click();
  await expect(page).toHaveURL(/\/content\/materials\/m1\/content\/new$/);
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.block-card')).toHaveCount(0);
  await page.locator('.add-block__item', { hasText: 'External link' }).click();
  await page.locator('input[type="url"]').fill('https://example.com/reading');
  await page.getByRole('button', { name: 'Save Draft' }).click();
  await expect(page).toHaveURL(/\/content\/materials\/m1\/view$/);
  expect(saved?.blocks?.map((block) => block.kind)).toEqual(['text', 'link']);
});

test('Accounts is hidden and blocked without expense permission', async ({ page }) => {
  await mockStaff(page, ['content:update']);
  await page.goto('/content');
  await expect(page.locator('.sidebar-link span')).toHaveText(['Home', 'Content', 'Packages']);
  await page.goto('/content/accounts');
  await expect(page).toHaveURL(/\/forbidden$/);
});

test('material editor saves any combination of optional blocks to an existing week', async ({ page }) => {
  let saved: Record<string, unknown> | null = null;
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1/subjects/s1/outline') return ok(route, outline);
    if (path === '/manage/materials' && route.request().method() === 'POST') {
      saved = route.request().postDataJSON() as Record<string, unknown>;
      return ok(route, { id: 'm1', title: { en: 'Session 1' }, status: 'draft', scheduledAt: null, publishedAt: null, updatedAt: '2026-09-01T00:00:00Z', weekId: 'w1', packageId: 'p1', subjectId: 's1', blocks: [] }, 201);
    }
    if (path === '/manage/materials/m1') return ok(route, { id: 'm1', title: { en: 'Session 1' }, status: 'draft', scheduledAt: null, publishedAt: null, updatedAt: '2026-09-01T00:00:00Z', weekId: 'w1', packageId: 'p1', subjectId: 's1', blocks: [] });
    return undefined;
  });
  await page.goto('/content/courses/p1/subjects/s1/weeks/w1/materials/new');
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.cm-editor-step')).toHaveCount(0);
  await expect(page.locator('.cm-material-section')).toHaveCount(2);
  await page.getByLabel('Material title (English)').fill('Session 1');
  await expect(page.locator('.add-block__item')).toHaveCount(8);
  await expect(page.locator('.block-card')).toHaveCount(0);
  await expect(page.getByLabel('Week')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Publish' })).toBeDisabled();

  await page.locator('.add-block__item', { hasText: 'Text' }).click();
  await page.getByLabel('Text (English)').fill('Read chapter 3.');
  await page.locator('.add-block__item', { hasText: 'External link' }).click();
  await page.locator('input[type="url"]').fill('https://example.com/reading');
  await page.locator('.add-block__item', { hasText: 'Quiz' }).click();
  await page.locator('.cm-quiz-question__toggle').click();
  await page.getByLabel('Question (English)').fill('2 + 2?');
  await page.getByLabel('Answer 1 (English)').fill('4');
  await page.getByLabel('Answer 2 (English)').fill('5');
  await page.locator('.block-card').last().locator('.block-card__actions').getByRole('button', { name: 'Move up' }).click();
  await page.getByRole('button', { name: 'Publish' }).click();
  await expect(page).toHaveURL(/\/content\/courses\/p1\/subjects\/s1\/weeks\/w1$/);

  expect(saved).toMatchObject({ title: { en: 'Session 1' }, weekId: 'w1', status: 'published' });
  const blocks = (saved as unknown as { blocks: { kind: string }[] }).blocks;
  expect(blocks.map((block) => block.kind)).toEqual(['text', 'quiz', 'link']);
  expect(blocks[1]).toMatchObject({ quiz: { questions: [{ type: 'mcq', options: [{ text: { en: '4' }, isCorrect: true }, { text: { en: '5' }, isCorrect: false }] }] } });
});

test('video block accepts a Bunny URL without upload controls when uploads are unavailable', async ({ page }) => {
  let saved: { blocks?: { kind: string; videoId?: string }[] } | null = null;
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1/subjects/s1/outline') return ok(route, outline);
    if (path === '/manage/videos/config') return ok(route, { enabled: false });
    if (path === '/manage/materials' && route.request().method() === 'POST') {
      saved = route.request().postDataJSON() as typeof saved;
      return ok(route, { id: 'm3', title: { en: 'Video lesson' }, status: 'draft', scheduledAt: null, publishedAt: null, updatedAt: '2026-09-01T00:00:00Z', weekId: 'w1', packageId: 'p1', subjectId: 's1', blocks: [] }, 201);
    }
    return undefined;
  });
  await page.goto('/content/courses/p1/subjects/s1/weeks/w1/materials/new');
  await page.getByLabel('Material title (English)').fill('Video lesson');
  await page.locator('.add-block__item', { hasText: 'Video' }).click();
  await page.getByLabel('Video URL or ID').fill('https://iframe.mediadelivery.net/embed/1234/abc-123');
  await expect(page.getByRole('button', { name: 'Upload video' })).toHaveCount(0);
  await page.getByRole('button', { name: 'Save Draft' }).click();
  await expect(page).toHaveURL(/\/content\/courses\/p1\/subjects\/s1\/weeks\/w1$/);
  expect(saved?.blocks?.[0]).toMatchObject({ kind: 'video', videoId: 'abc-123' });
});

test('quiz keeps a long question list compact and edits one question at a time', async ({ page }) => {
  await mockStaff(page, all, (route, path) => path === '/manage/packages/p1/subjects/s1/outline' ? ok(route, outline) : undefined);
  await page.goto('/content/courses/p1/subjects/s1/weeks/w1/materials/new');
  await page.locator('.add-block__item', { hasText: 'Quiz' }).click();
  await expect(page.locator('.cm-quiz-question')).toHaveCount(1);
  await expect(page.locator('.question-card')).toHaveCount(0);
  for (let index = 0; index < 19; index++) {
    await page.getByRole('button', { name: 'Add Question' }).click();
    await page.locator('.quiz-builder__type-menu').getByRole('button', { name: 'Multiple choice' }).click();
  }
  await expect(page.locator('.cm-quiz-question')).toHaveCount(20);
  await expect(page.locator('.question-card')).toHaveCount(1);
  await page.locator('.cm-quiz-question').last().getByRole('button', { name: 'More actions' }).click();
  await page.getByRole('button', { name: 'Change to True / False' }).click();
  await expect(page.getByLabel('Answer 1 (English)')).toHaveCount(0);
  await page.getByRole('button', { name: 'Done' }).click();
  await expect(page.locator('.question-card')).toHaveCount(0);
  await expect(page.locator('.option-row')).toHaveCount(0);
  await expect(page.getByText('Advanced settings')).toBeVisible();
  await page.locator('.cm-quiz-question__toggle').first().click();
  await expect(page.locator('.question-card')).toHaveCount(1);
  await page.setViewportSize({ width: 390, height: 780 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test('a material can be saved as a draft before adding blocks', async ({ page }) => {
  let saved: Record<string, unknown> | null = null;
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1/subjects/s1/outline') return ok(route, outline);
    if (path === '/manage/materials' && route.request().method() === 'POST') {
      saved = route.request().postDataJSON() as Record<string, unknown>;
      return ok(route, { id: 'm2', title: { en: 'Outline' }, status: 'draft', scheduledAt: null, publishedAt: null, updatedAt: '2026-09-01T00:00:00Z', weekId: 'w1', packageId: 'p1', subjectId: 's1', blocks: [] }, 201);
    }
    if (path === '/manage/materials/m2') return ok(route, { id: 'm2', title: { en: 'Outline' }, status: 'draft', scheduledAt: null, publishedAt: null, updatedAt: '2026-09-01T00:00:00Z', weekId: 'w1', packageId: 'p1', subjectId: 's1', blocks: [] });
    return undefined;
  });
  await page.goto('/content/courses/p1/subjects/s1/weeks/w1/materials/new');
  await page.getByLabel('Material title (English)').fill('Outline');
  await page.getByRole('button', { name: 'Save Draft' }).click();
  await expect(page).toHaveURL(/\/content\/courses\/p1\/subjects\/s1\/weeks\/w1$/);
  expect(saved).toMatchObject({ title: { en: 'Outline' }, weekId: 'w1', status: 'draft', blocks: [] });
});

test('accounts shows every expense but only the author gets edit controls', async ({ page }) => {
  const expense = (id: string, title: string, canEdit: boolean) => ({ id, title, category: 'software', amount: 100, currency: 'EGP', date: '2026-09-01T00:00:00Z', description: null, notes: null, receipt: null, createdBy: { id: canEdit ? 'u1' : 'u2', name: canEdit ? 'Nour Hassan' : 'Omar Adel' }, canEdit, createdAt: '2026-09-01T00:00:00Z', updatedAt: '2026-09-01T00:00:00Z' });
  await mockStaff(page, all, (route, path) => (path === '/manage/expenses'
    ? ok(route, { items: [expense('e1', 'Figma', true), expense('e2', 'Hosting', false)], total: 2, page: 1, pageSize: 25, totals: [{ currency: 'EGP', amount: 200 }] })
    : undefined));
  await page.goto('/content/accounts');
  await expect(page.locator('.manage-table tbody tr')).toHaveCount(2);
  await expect(page.getByRole('button', { name: 'Edit expense: Figma' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Edit expense: Hosting' })).toHaveCount(0);
  await expect(page.locator('.cm-account-summary strong').nth(1)).toContainText('200');
});

test('course page lays out correctly in Arabic', async ({ page }) => {
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1') return ok(route, pkg);
    if (path === '/manage/packages/p1/subjects') return ok(route, subjects);
    if (path === '/manage/courses') return ok(route, []);
    return undefined;
  }, 'ar');
  await page.goto('/content/courses/p1');
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  await expect(page.getByRole('link', { name: /Programming/ })).toBeVisible();
  await expect(page.getByText('Linked lists')).toHaveCount(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
});

test('content manager content creation page adapts to dark mobile layout', async ({ page }) => {
  await mockStaff(page, all, (route, path) => {
    if (path === '/manage/packages/p1/subjects/s1/outline') return ok(route, outline);
    return undefined;
  }, 'en', 'dark');
  await page.setViewportSize({ width: 390, height: 780 });
  await page.goto('/content/courses/p1/subjects/s1/weeks/w1/materials/new');
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page.locator('.add-block__item')).toHaveCount(8);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  await page.getByRole('button', { name: 'Cancel' }).click();
  await expect(page).toHaveURL(/\/content\/courses\/p1\/subjects\/s1\/weeks\/w1$/);
});

test('package form stays compact in a modal on desktop and mobile', async ({ page }) => {
  await mockStaff(page, all, (route, path) => path === '/manage/packages' ? ok(route, [pkg]) : undefined);
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.goto('/content/packages');
  await page.getByRole('button', { name: 'Edit package' }).click();
  const modal = page.getByRole('dialog');
  await expect(modal).toBeVisible();
  await expect(modal.locator('.form-section')).toHaveCount(2);
  await expect(modal.getByLabel('Price')).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollHeight <= window.innerHeight)).toBe(true);
  await page.setViewportSize({ width: 390, height: 780 });
  await expect(modal).toBeVisible();
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  const priceWidth = await modal.getByLabel('Price').evaluate((input) => input.getBoundingClientRect().width);
  expect(priceWidth).toBeGreaterThan(250);
});
