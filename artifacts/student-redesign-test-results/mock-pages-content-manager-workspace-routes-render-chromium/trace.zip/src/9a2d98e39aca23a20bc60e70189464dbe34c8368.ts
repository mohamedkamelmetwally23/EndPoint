import { expect, test, type Page } from '@playwright/test';

type Role = 'student' | 'lecturer' | 'content_manager' | 'super_admin';

const routes: Record<Role, string[]> = {
  student: ['/student', '/student/timeline', '/student/explore', '/student/profile'],
  lecturer: ['/lecturer', '/lecturer/subjects', '/lecturer/students', '/lecturer/analytics', '/lecturer/accounts'],
  content_manager: ['/content', '/content/packages', '/content/courses', '/content/accounts'],
  super_admin: ['/admin', '/admin/students', '/admin/access', '/admin/users', '/admin/settings'],
};

async function mockUser(page: Page, role: Role): Promise<void> {
  await page.addInitScript(() => {
    localStorage.setItem('endpoint.language', 'en');
    localStorage.setItem('endpoint.theme', 'light');
  });
  await page.route('http://localhost:4000/api/v1/**', async (route) => {
    const path = new URL(route.request().url()).pathname;
    if (path.endsWith('/auth/device')) return route.fulfill({ json: { success: true, data: { initialized: true } } });
    if (path.endsWith('/auth/refresh')) return route.fulfill({ json: { success: true, data: { accessToken: 'mock-pages-token' } } });
    if (path.endsWith('/auth/me')) return route.fulfill({ json: { success: true, data: {
      id: `${role}-1`, name: 'Endpoint Demo', email: 'demo@endpoint.dev', roles: [role],
      permissions: { content_manager: ['content:update', 'expense:manage'], lecturer: ['student:read', 'analytics:read', 'expense:manage'], student: [], super_admin: [] }[role],
      preferences: { language: 'en', theme: 'light' },
    } } });
    return route.fulfill({ status: 404, json: { success: false } });
  });
}

for (const role of Object.keys(routes) as Role[]) {
  test(`${role} workspace routes render`, async ({ page }) => {
    test.setTimeout(60_000);
    await mockUser(page, role);
    for (const path of routes[role]) {
      await page.goto(path);
      await expect(page.locator('main h1')).toBeVisible();
      await expect(page.locator('.center-message')).toHaveCount(0);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
    }
  });
}
