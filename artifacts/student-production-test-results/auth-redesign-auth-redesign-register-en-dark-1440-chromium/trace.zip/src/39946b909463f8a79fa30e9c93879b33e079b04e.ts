﻿import { expect, test } from '@playwright/test';

for (const language of ['ar', 'en']) for (const theme of ['dark', 'light']) for (const width of [390, 1440]) for (const path of ['/login', '/register']) {
  test(`auth redesign ${path} ${language} ${theme} ${width}`, async ({ page }) => {
    await page.setViewportSize({ width, height: 900 });
    await page.addInitScript(({ language, theme }) => {
      localStorage.setItem('endpoint.language', language);
      localStorage.setItem('endpoint.theme', theme);
    }, { language, theme });
    await page.route('http://localhost:4000/api/v1/**', route => route.fulfill({ status: 401, json: { success: false, error: { code: 'AUTH_REQUIRED' } } }));
    await page.goto(path);
    await expect(page.locator('html')).toHaveAttribute('dir', language === 'ar' ? 'rtl' : 'ltr');
    await expect(page.locator('html')).toHaveAttribute('data-theme', theme);
    await expect(page.locator('.auth-hero__visual img')).toBeVisible();
    expect(await page.locator('.auth-hero__visual img').evaluate((image: HTMLImageElement) => image.complete && image.naturalWidth > 0)).toBe(true);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    const input = page.locator('input[name="email"]');
    await expect(input).toBeVisible();
    expect(await input.evaluate(element => element.getBoundingClientRect().height)).toBe(width >= 768 ? 46 : 50);
    if (width === 1440) {
      const usableWidth = await input.evaluate(element => element.getBoundingClientRect().width);
      expect(usableWidth).toBeGreaterThanOrEqual(430);
      expect(usableWidth).toBeLessThanOrEqual(470);
    }
    const background = await input.evaluate(element => getComputedStyle(element).backgroundColor);
    expect(background).toBe(theme === 'dark' ? 'rgb(16, 38, 59)' : 'rgb(255, 255, 255)');
    await page.locator('.auth-submit').click();
    await expect(input).toHaveAttribute('aria-invalid', 'true');
    await expect(page.locator('#email-error')).toBeVisible();
    await page.locator('.auth-eye').first().click();
    await expect(page.locator('input[name="password"]')).toHaveAttribute('type', 'text');
    if (path === '/register' && width === 390) {
      const password = await page.locator('input[name="password"]').boundingBox();
      const confirm = await page.locator('input[name="confirmPassword"]').boundingBox();
      expect(confirm!.y).toBeGreaterThan(password!.y + password!.height);
    }
  });
}

test('wrong credentials, recovery help, and loading stay inside the form', async ({ page }) => {
  await page.route('http://localhost:4000/api/v1/**', async route => {
    const path = new URL(route.request().url()).pathname;
    if (path.endsWith('/auth/device')) return route.fulfill({ json: { success: true, data: { initialized: true } } });
    if (path.endsWith('/auth/login')) {
      await new Promise(resolve => setTimeout(resolve, 500));
      return route.fulfill({ status: 401, json: { success: false, error: { code: 'INVALID_CREDENTIALS' } } });
    }
    if (path.endsWith('/auth/google/status')) {
      await new Promise(resolve => setTimeout(resolve, 500));
      return route.fulfill({ json: { success: true, data: { configured: false } } });
    }
    return route.fulfill({ status: 401, json: { success: false, error: { code: 'AUTH_REQUIRED' } } });
  });
  await page.goto('/login');
  await page.locator('.auth-text-button').click();
  await expect(page.locator('#recovery-help')).toBeVisible();
  await page.locator('[name="email"]').fill('student@example.com');
  await page.locator('[name="password"]').fill('wrong-password');
  await page.locator('.auth-submit').click();
  await expect(page.locator('.auth-submit')).toBeDisabled();
  await expect(page.getByRole('alert')).toContainText('incorrect');
  await page.locator('.auth-google').click();
  await expect(page.locator('.auth-google')).toBeDisabled();
  await expect(page.getByRole('alert')).toContainText('not configured');
});

test('language and theme controls update both auth pages', async ({ page }) => {
  await page.addInitScript(() => {
    localStorage.setItem('endpoint.language', 'en');
    localStorage.setItem('endpoint.theme', 'light');
  });
  await page.route('http://localhost:4000/api/v1/**', route => route.fulfill({ status: 401, json: { success: false } }));
  await page.goto('/login');
  await page.locator('.auth-toolbar button').first().click();
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  await page.locator('.auth-toolbar button').last().click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await page.locator('.auth-switch a').click();
  await expect(page).toHaveURL(/register$/);
  await expect(page.locator('html')).toHaveAttribute('dir', 'rtl');
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
});
